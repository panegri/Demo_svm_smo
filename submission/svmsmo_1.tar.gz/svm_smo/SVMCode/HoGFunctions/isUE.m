function out = isUE(filename)
out = length(strfind(filename,'Griegas'));