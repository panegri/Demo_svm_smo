function out = isEEUU(filename)
out = length(strfind(filename,'Dlagnekov'));