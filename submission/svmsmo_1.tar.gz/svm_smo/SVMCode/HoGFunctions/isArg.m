function out = isArg(filename)
out = length(strfind(filename,'Argentina'));