function out = isPak(filename)
out = length(strfind(filename,'Pakistan'));