mex -O -largeArrayDims getHogData_c.cpp
